configuration AddSessionHost
{
    param
    (    
        [Parameter(mandatory = $true)]
        [string]$RegistrationToken
    )
 
 	$rdshIsServer = $true
    $ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

    $OSVersionInfo = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"
    
    if ($OSVersionInfo -ne $null)
    {
        if ($OSVersionInfo.InstallationType -ne $null)
        {
            $rdshIsServer=@{$true = $true; $false = $false}[$OSVersionInfo.InstallationType -eq "Server"]
        }
    }

    ##[ValidateSet('All','WindowsMediaPlayer','AppxPackages','ScheduledTasks','DefaultUserSettings','Autologgers','Services','NetworkOptimizations','LGPO','DiskCleanup')] 
    $Optimizations ="All" 
    
    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }

                
        Script ExecuteRdAgentInstallClient
        {
            GetScript = {
                return @{'Result' = ''}
            }
            SetScript = {
               & "$using:ScriptPath\Script-AddRdshServer.ps1" -RegistrationToken $using:RegistrationToken
            }
            TestScript = {
                return (Test-path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDInfraAgent")
            }
        }
        
        Script ExecuteOneDrive
        {
            GetScript = {
                return @{'Result' = ''}
            }
            SetScript = {
                & "$using:ScriptPath\Script-InstallOneDrive.ps1" 
            }
            TestScript = {
                return (Test-path "c:\temp\OneDrive\")
            }
        }
        
   
        Script ExecuteWinOptimize
        {
            GetScript = {
                return @{'Result' = ''}
            }
            SetScript = {
                & "$using:ScriptPath\StartWinOptimize.ps1" -Optimizations $using:Optimizations 
            }
            TestScript = {
                return (Test-path "c:\DeployAgent\Win10_Optimize")
            }
        }
        
        DefenderATPonboarding
        {
			    Write-Log -Message "Onboarding machines to the Microsoft Defender for Endpoint services started "
			    C:\deployagent\WindowsDefenderATPLocalOnboardingScript.cmd   
			    Write-Log -Message "Onboarding machines to the Microsoft Defender for Endpoint services finished"
        }
    }
}
